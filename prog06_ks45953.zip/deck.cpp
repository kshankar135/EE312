#include "deck.h"
#include <cstdlib>
#include <ctime>
using namespace std;

Deck::Deck(){
    unsigned int currentTime = (unsigned)time(0);
    srand(currentTime);

    myIndex = 0;
    int r = 0;
    int s = 0;
    for(int i = 0; i < SIZE; i++){
        s = i%4;
        if(s == 0)
            r++;
        Card c(r, (Card::Suit)s);
        myCards[i] = c;
    }
}

// shuffle the deck, all 52 cards present
void Deck::shuffle(){
    for(int i = 0; i < SIZE; i++){
        int j = rand()%SIZE;    // returns random number less than 52
        Card temp = myCards[i]; // holds card in index

        myCards[i] = myCards[j];    // switch cards at i and j
        myCards[j] = temp;

    }
    myIndex = 0;    // reset card index because new game (shuffle)
}

// get a card, after 52 are dealt, fail
Card Deck::dealCard(){
    Card temp(0,(Card::Suit)0);

    if(myIndex < 52){
        temp = myCards[myIndex];
        myIndex++;
        return temp;
    }
    else{
        cout << "no cards left";
        return temp;
    }

}

// # cards left in the deck
int  Deck::size() const{
    return SIZE-myIndex;
}