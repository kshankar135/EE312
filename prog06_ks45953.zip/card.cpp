#include "card.h"
#include <iostream>
#include <cstdio>
using namespace std;

Card::Card(){
    myRank = 1;
    mySuit = spades;
}

Card::Card(int rank, Suit s){
    myRank = rank;
    mySuit = s;
}

// return string version e.g. Ac 4h Js
string Card::toString() const{
    string R = rankString(myRank);
    string S = suitString(mySuit);
    return R+S;
}

// return true if suit same as c
bool Card::sameSuitAs(const Card& c) const{
    if(c.mySuit == mySuit)
        return true;
    else
        return false;
}

// return rank, 1...13
int Card::getRank() const{
    return myRank;
}

// return "s", "h",...
string Card::suitString(Suit s) const{
    if(s == spades)
        return "s";
    else if(s == hearts)
        return "h";
    else if(s == diamonds)
        return "d";
    else if(s == clubs)
        return "c";
    else
        return "";
}

//return "A", "2", ... "Q"
string Card::rankString(int r) const{
    if(r == 1)
        return "A";
    else if(r == 2)
        return "2";
    else if(r == 3)
        return "3";
    else if(r == 4)
        return "4";
    else if(r == 5)
        return "5";
    else if(r == 6)
        return "6";
    else if(r == 7)
        return "7";
    else if(r == 8)
        return "8";
    else if(r == 9)
        return "9";
    else if(r == 10)
        return "10";
    else if(r == 11)
        return "J";
    else if(r == 12)
        return "Q";
    else if(r == 13)
        return "K";
    else
        return "";
}

bool Card::operator == (const Card& rhs) const{
    if(rhs.getRank() == getRank()){
        return true;
    }
    else
        return false;
}

bool Card::operator != (const Card& rhs) const{
    if(rhs.getRank() != getRank()){
        return true;
    }
    else
        return false;
}

ostream& operator << (ostream& out, const Card& c){
    out << c.toString();
    return out;
}



