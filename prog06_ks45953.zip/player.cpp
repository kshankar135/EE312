#include "player.h"
#include <cstdlib>
#include <string>
#include <vector>
using namespace std;

Player::Player(){

}

//adds a card to the hand
void Player::addCard(Card c){

}

void Player::bookCards(Card c1, Card c2){

}

//uses some strategy to choose one card from the player's
//hand so they can say "Do you have a 4?"
Card Player::chooseCardFromHand() const{
    Card temp(0, (Card::Suit)0);
    return temp;
}

//Does the player have the card c in her hand?
bool Player::cardInHand(Card c) const{
    return true;
}

//Remove the card c from the hand and return it to the caller
Card Player::removeCardFromHand(Card c){
    Card temp(0, (Card::Suit)0);
    return temp;
}

string Player::showHand() const{
    return "test";
}

string Player::showBooks() const{
    return "test";
}

int Player::getHandSize() const{
    return 0;
}
int Player::getBookSize() const{
    return 0;
}
